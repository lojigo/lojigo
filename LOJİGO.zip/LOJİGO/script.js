// Henüz belirli bir JavaScript fonksiyonu yok. Gelecekte dinamik özellikler eklemek için bu dosyayı kullanabilirsiniz.
document.addEventListener('DOMContentLoaded', function() {
    // Örneğin, butonlara tıklanıldığında ekstra animasyonlar ekleyebilirsiniz.
});
